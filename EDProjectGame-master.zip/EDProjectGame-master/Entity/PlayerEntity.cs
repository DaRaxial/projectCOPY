﻿using _1234son.Enemy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6.Класс.Entity //"Олег", "Крутой воин", 12, 100, 100, 10, 0.2f, 2f

{
    internal class PlayerEntity : BaseEntity
    {
        public PlayerEntity(
            string name = "Олег",
            string descripthion = "Воин",
            int age = 10,
            float maxHealfPoint = 100,
            float maxShieldPoint = 100,
            float attackDamage = 10,
            float critChance = 0.2f,
            float critMultiplier = 2.0f
            ) : base(
                name,
                descripthion,
                age,
                maxHealfPoint,
                maxShieldPoint,
                attackDamage,
                critChance,
                critMultiplier
            )
        {

        }
    }
}
