﻿using ConsoleApp6.Класс.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace _1234son.Enemy.Entity
{
    internal class SpyderEntity : BaseEntity
    {
        // Атакующие характеристики яда
        private float _poisonChance;
        private float _poisonDamage;

        public SpyderEntity(
            string name = "Паук-Маук",
            string description = "Ядовитый паук-маук, суетолог дикий",
            int age = 157,
            float maxHealthPoint = 50,
            float maxShieldPoint = 0,
            float attackDamage = 35,
            float critChance = 0.1f,
            float critMultiplier = 3.5f,
            float poisonChance = 0.4f,
            float poisonDamage = 15f
        ) : base(
            name,
            description,
            age,
            maxHealthPoint,
            maxShieldPoint,
            attackDamage,
            critChance,
            critMultiplier
        )
        {
            //Инициализируем поля класса
            this._poisonChance = poisonChance;
            this._poisonDamage = poisonDamage;
        }

        // Переопределяем базовые методи родительского класса
        public override float DealDamage()
        {
            // Сначала получаем базовый урон от сущности
            float baseDamage = base.DealDamage();

            // Реализуем метод отравления (доп. урон от яда)
            if ((float)this._random.NextDouble() < _poisonChance)
            {
                return baseDamage + this._poisonDamage;
            }
            return baseDamage;
        }
    }
}
