﻿using ConsoleApp6.Класс.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace _1234son.Entity.Enemy
{
    public class SkeletonEntity : BaseEntity
    {
        private float _dieChance;
        public SkeletonEntity(
            string name = "Миша",
            string description = "Крепкий орешек",
            int age = 95,
            float maxHealthPoint = 20.0f,
            float maxShieldPoint = 20.0f,
            float attackDamage = 5.0f, 
            float critChance = 0.2f,
            float critMultiplier = 2f,
            float dieChance = 0.4f
            ) : base(
            name,
            description,
            age,
            maxHealthPoint,
            maxShieldPoint,
            attackDamage,
            critChance,
            critMultiplier
            )
        {
            this._dieChance = dieChance;
        }
        
        // Внутренний метод
        private bool RollDie()
        {
            return (float)this._random.NextDouble() < this._dieChance;
        }

        // Поведение класса (методы)
        public override void TakeDamage(float damage)
        {
            if (RollDie())
            {
                this.InstantDie();
            }

            base.TakeDamage(damage);
        }
        /*public override float DealDamage()
        {
            float baseDamage = base.DealDamage();
            
            if ((float)this._random.NextDouble() < damage)
            {
                return baseDamage;
            }
            return baseDamage;
        }*/
    }
}
