﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6.Класс.Entity
{
    public class BaseEntity
    {
        //Базовая информация (приватные поля)
        private string _name;
        private string _description;
        private int _age;

        //Базовые характеристики (приватные поля)
        private float _healthPoint = 100.0f;
        private float _shieldPoint = 50.0f;

        private float _maxHealthPoint = 100.0f;
        private float _maxShieldPoint = 100.0f;

        //Базовые боевые характеристики (приватные поля)
        private float _attakDamage = 10.0f;
        private float _critCance = 0.2f;
        private float _critMultiplier = 2f;

        //Серверные поля (private readonly)
        protected readonly Random _random;

        // Базовые свойства класса
        public float HealthPoint
        {
            get { return _healthPoint; }
        }

        public float ShieldPoint
        {
            get { return _shieldPoint; }
        }

        public float MaxHealthPoint
        {
            get { return _maxHealthPoint; }
        }

        public float MaxShieldPoint
        {
            get { return _maxShieldPoint; }
        }

        // Анонимные методы класса
        public bool IsDead => _healthPoint <= 0; // Если хп меньше нуля - сущность мертва

        //Сервисные поля (private)
        //Инвентарь
        //Баффы, дебафы

        //Конструктор базового класса
        public BaseEntity(
            string name,
            string descripthion,
            int age,
            float maxHealthPoint,
            float maxShieldPoint,
            float attackDamage,
            float critChance,
            float critMultiplier
            )
        {
            this._name = name;
            this._description = descripthion;
            this._age = age;

            this._healthPoint = maxHealthPoint = Math.Max(maxHealthPoint, this._healthPoint);
            this._shieldPoint = maxShieldPoint = Math.Max(maxShieldPoint, this._shieldPoint);

            this._attakDamage = attackDamage;
            this._critCance = critChance;
            this._critMultiplier = critMultiplier;

            // Инциаьлизация сервисных полей
            this._random = new Random();
        }

        //Внутренние методы
        private bool RoolCrit() // Возможность нанести критический урон
        {
            return (float)this._random.NextDouble() < this._critCance;
        }

        //Базовок поведение
        public virtual void TakeDamage(float damage) // Метод получения урона
        {
            if (damage <= 0) // Если урона нет, значит ничего не делается
                return;

            if (damage <= this._attakDamage)
            {
                this._shieldPoint -= damage;
                return;
            }

            damage -= this._shieldPoint;
            this._shieldPoint = 0;
            if ((this._healthPoint - damage) <= 0)
            {
                this._healthPoint = 0;
                return;
            }

            this._healthPoint -= damage;
        }

        public virtual float DealDamage() // Метод нанесения урона
        {
            float baseDamage = this._attakDamage;

            if (RoolCrit()) // Проверка на шанс Крита
            {
                return baseDamage * this._critMultiplier;
            }
            return baseDamage;
        }

        public virtual void Heal(float amount) // Лечение героя, например аптечкой
        {
            this._healthPoint = Math.Min(this._shieldPoint + amount, this._maxHealthPoint);
        }

        public virtual void RecoveryShield(float amount) // Восстановление щита, например магией
        {
            this._shieldPoint = Math.Min(this._shieldPoint + amount, this._maxShieldPoint);
        }
        // Метод для наследника SkeletonEntity
        protected bool InstantDie() // TODO: Доработать для TRY...CATCH
        {
            try
            {
                this._healthPoint = 0;
                return true;
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Ошибка!!!! {ex}");
                return false;
            }
        }  
    }
}
// Task: try-catch изучить подробнее.
