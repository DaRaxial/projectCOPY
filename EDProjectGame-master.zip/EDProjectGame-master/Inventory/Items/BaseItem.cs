﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1234son.Inventory.Items
{
    interface IBaseItem // При создании интерфейса, его название обязано начинаться с 'I' !!!
    {
        // Использование предмета
        void Use();

        // Разрушение предмета
        bool Destroy();

        // Модифицирование предмета
        bool Modify();
    }
}
